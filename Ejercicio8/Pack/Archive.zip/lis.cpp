#include<bits/stdc++.h>
using namespace std;

int lis(vector<int>v)
{
	int ls[v.size()];

	ls[0] = 1;

	for(int i = 1; i < v.size(); i++)
	{
		ls[i] = 1;
		for(int j = 0; j < i; j++)
			if(v[i] > v[j] && ls[i] < ls[j] + 1)
				ls[i] = ls[j] + 1;
	}
	return *max_element(ls,ls+v.size());
}

int main()
{
	int n;
	cin>>n;
	vector<int>v(n);
	for(int i = 0; i < n; i++)
		cin>>v[i];
	cout<<lis(v)<<endl;
}