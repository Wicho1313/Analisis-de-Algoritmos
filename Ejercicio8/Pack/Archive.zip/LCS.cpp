#include<bits/stdc++.h>
using namespace std;


void LCS(string a,string b)
{
	int v[a.size()+1][b.size()+1];
	for(int i = 0; i <= a.size(); i++)
		for(int j = 0; j <= b.size(); j++)
		{
			if(i == 0 || j == 0)
				v[i][j] = 0;
			else if(a[i-1] == b[j-1])
				v[i][j] = v[i-1][j-1] + 1;
			else
				v[i][j] = max(v[i-1][j],v[i][j-1]);
		}
	int in = v[a.size()][b.size()];
	vector<char> lcs(in + 1);
	lcs[in] = ' ';

	int i = a.size(), j = b.size();

	while(i > 0 && j > 0)
	{
		if(a[i-1] == b[j-1])
		{
			lcs[in-1] = a[i -1];
			i--; j--; in--;
		}
		else if(v[i-1][j] > v[i][j - 1])
			i--;
		else
			j--;
	}
	cout<<lcs.size()-1<<endl;
}

int main()
{
	string a,b;
	cin>>a>>b;
	LCS(a,b);
}