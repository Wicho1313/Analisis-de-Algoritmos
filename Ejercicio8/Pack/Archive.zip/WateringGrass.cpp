#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;


int main()
{
    int T, largo,num,ancho;
    
    cin >> T;
    
    while (T--)
    {
        int pos,rad;
        cin >> num >> largo >> ancho;
        vector< pair<int,int> > v(num);
        for(int i = 0; i < num; i++)
        {
            cin >> pos >> rad;
            if(rad>=ancho)
                v[i]=make_pair(pos,rad);
        }
        
    }

}
